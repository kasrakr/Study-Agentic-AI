import "@testing-library/jest-dom/vitest";
import { cleanup } from "@testing-library/react";
import { afterEach } from "vitest";

afterEach(cleanup);

// jsdom doesn't implement layout APIs the UI calls.
if (typeof Element !== "undefined") Element.prototype.scrollIntoView = () => {};
